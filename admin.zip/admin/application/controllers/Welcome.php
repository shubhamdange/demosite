<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{

		//echo "am index";
		$this->load->view('top');
		$this->load->view('index');
		$this->load->view('bottom');
		//$this->load->view('welcome_message');
	}














	public function insertdata()
	{

		print_r($_POST);

		// 	$data["name"] = $this->input->post('name');

		//  $data["number"]= $this->input->post('number');

		$formArray = $_POST;

		$this->load->model('insertFun');

		$this->insertFun->insertData($formArray);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public function updatedata()
	{
		echo "<pre>";
		print_r($_POST);
		$data["name"] = "from update";

		$data["number"] =  "from update2";

		$keyword = 1;

		$this->load->model('insertFun');

		$this->insertFun->updateData($keyword, $data);
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public function records()
	{

		$filter = "filterOptions.php";
		$this->load->view('top');

		///////////////////////////////////////
		$this->load->model('insertFun');

		$details["mydata"] = $this->insertFun->showData();
		///////////////////////////////////////////////


		$this->load->view('show', $details, $filter);
		$this->load->view('bottom');
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public function bloodGroup()
	{
		$this->load->view('top');

		///////////////////////////////////////
		$this->load->model('insertFun');

		$details["mydata"] = $this->insertFun->showData();
		///////////////////////////////////////////////


		$this->load->view('bloodgroupView', $details);
		$this->load->view('bottom');
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public function searchby()
	{

		$keyword = $this->input->get('keyword');
		$colName = $this->input->get('colName');

		$this->load->view('top');

		///////////////////////////////////////
		$this->load->model('insertFun');

		$details["mydata"] = $this->insertFun->selectedData($keyword, $colName);
		///////////////////////////////////////////////


		$this->load->view('show', $details);




		$this->load->view('bottom');
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public function searchbyblood()
	{

		$keyword = $this->input->get('bloodType');


		$this->load->view('top');

		///////////////////////////////////////
		$this->load->model('insertFun');

		$details["mydata"] = $this->insertFun->selectedBlood($keyword);
		///////////////////////////////////////////////


		$this->load->view('show', $details);
		$this->load->view('bottom');
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




















	public function showDetails()
	{



		$this->load->helper(array("url"));


		$this->load->view('top');
		$this->load->model('detailsLoad');
		$details["mydata"] = $this->detailsLoad->loadDetails();

		$this->load->view('alldetails', $details);
		$this->load->view('bottom');
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public function updteData()
	{


		$this->load->model('detailsLoad');
		$details["mydata"] = $this->detailsLoad->loadDetails();

		$this->load->view('updatePage', $details);
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



}
