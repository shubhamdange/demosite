<div class="content-bottom" style="background-color: white;;">


  <div class="row show-grid" style=" margin-left:50px">

    <!-------------------filter options end------------------------------>
    <?php


    $this->load->view('filterOptions-regular');

    ?>

    <!-------------------filter options end------------------------------>
    <h5 align="center" style="padding-bottom:50px; ">Overview</h5>





    <div class="col-xs-4 col-sm-4" style="background-color:white;">
      <p align="center"> Count <br><label><?php echo count($mydata); ?></label></p>
    </div>
    <div class="col-xs-4 col-sm-4" style="background-color:white;">
      <p align="center">Avarage Age <br><label id="totolBasicDiv">NA</label></p>
    </div>


    <div class="col-xs-4 col-sm-4" style="background-color:white;">
      <p align="center">Fully Vaccinated <br><label id="totolBasicDiv"><?php echo count($mydata); ?></label></p>
    </div>


  </div>

  <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">

  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#example').DataTable();
    });
  </script>


  <div style="width:90%;">
    <table class="table table-hover table-bordered" id="example" style=" margin-left:50px">
      <thead>
        <tr>
          <th>Sr</th>
          <th>Name</th>
          <th>Contact</th>
          <th>Age</th>
          <th>Blood Group</th>
          <th>City</th>
          <th>Vaccination Status</th>
          <th>View</th>
        </tr>
      </thead>
      <tbody>




        <?php

        $countA = 0;
        $countB = 0;
        $countAB = 0;
        $countO = 0;

        for ($i = 0; $i < count($mydata); $i++) {

          if ($mydata[$i]->vaccineState == "2") {
            $vaccStat = "Fully";
          }

          if ($mydata[$i]->vaccineState == "1") {
            $vaccStat = "Partial";
          }


          if ($mydata[$i]->vaccineState == "0") {
            $vaccStat = "None";
          }
          $vaccineState;

          echo  "<tr><td>" . ($i + 1) . "</td><td>" . $mydata[$i]->name . " " . $mydata[$i]->lastName . "</td><td>" . $mydata[$i]->phone . "</td><td>" . $mydata[$i]->age . "</td><td>" . $mydata[$i]->bloodGroup . "</td><td>" . $mydata[$i]->city . "</td><td>" . $vaccStat . "</td><td>

<a href='showDetails?sr=" . $mydata[$i]->sr . "'>Detailed?</td></tr></a>";

          if ($mydata[$i]->bloodGroup == "A") {
            $countA = $countA + 1;
          }


          if ($mydata[$i]->bloodGroup == "B") {
            $countB = $countB + 1;
          }

          if ($mydata[$i]->bloodGroup == "AB") {
            $countAB = $countAB + 1;
          }


          if ($mydata[$i]->bloodGroup == "O") {
            $countO = $countO + 1;
          }
        }
        ?>
      </tbody>
    </table>
  </div>

</div>


<!------------------------Summery By Blood------------------------------------>

<?php $this->load->view('bloodSummery', $mydata); ?>
<!------------------------Summery By Blood------------------------------------>


</div>