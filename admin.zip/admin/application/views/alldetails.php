<?php
//print_r($mydata)
?>

<div class="col-lg-10" style=" font-size:18px;   border-left: 1px solid #E9E9E9; background-color:white">



  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#userdetails">General Details</a></li>
    <li><a data-toggle="tab" href="#vaccination1">Vaccination 1</a></li>
    <li><a data-toggle="tab" href="#vaccination2">Vaccination 2</a></li>

  </ul>





  <div class="tab-content">



    <div id="userdetails" class="tab-pane fade in active">
      <h4>Entry</h4>
      <p>
        <strong><?php echo $mydata[0]->name; ?> </strong><br>
        <strong>Mob : </strong><?php echo $mydata[0]->phone; ?><br>

        <strong>Address : </strong><?php echo $mydata[0]->city; ?><br>
        <strong>State :</strong><?php echo $mydata[0]->state; ?><br>
        <strong>Blood Group : </strong><?php echo $mydata[0]->bloodGroup; ?><br>
        <strong>Vacciantion :</strong> Fully<br>
      </p>
    </div>

    <div id="vaccination1" class="tab-pane fade in ">
      <h3>Vaccination 1 Details</h3>
      <p><?php echo $mydata[0]->CertImg; ?> <br /><a href=""><img src="file:///C:/xampp/htdocs/ci/site/assets/uploads/<?php echo $mydata[0]->CertImg; ?>" width="200" height="200" /></a></p>
      <p>Vaccination City : <?php echo  $mydata[0]->CertCity; ?></p>
      <p>Vaccination Date : <?php echo  $mydata[0]->vacc1date; ?></p>
    </div>


    <div id="vaccination2" class="tab-pane fade">
      <h3>Vaccination 2 Details</h3>
      <p><?php echo $mydata[0]->Cert2Img; ?> <br /><a href=""><img src="file:///C:/xampp/htdocs/ci/site/assets/uploads/<?php echo $mydata[0]->Cert2Img; ?>" width="200" height="200" /></a></p>
      <p>Vaccination City : <?php echo  $mydata[0]->Cert2City; ?></p>
      <p>Vaccination Date : <?php echo  $mydata[0]->vacc2date; ?></p>
    </div>

  </div>
</div>