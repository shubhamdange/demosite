<!--- inner grids-->

<a href='index.php/records'>
	<div class="col-xs-6 col-sm-3" style="background-color:white;"><img src="https://bangalorecalltaxi.com/billing/images/myusers.png" class="myCategory" />

		<p align="center"> <label>Vaccination Report
			</label></p>
	</div>
</a>


<div class="col-xs-6 col-sm-3" data-toggle="modal" data-target="#AddDesignProduct" style="background-color:white;"><img src="https://bangalorecalltaxi.com/billing/images/blood-tube.png" class="myCategory" />
	<p align="center"> <label>Blood Group Info</label></p>
</div>
<div class="col-xs-6 col-sm-3" style="background-color:white;"><img src="https://bangalorecalltaxi.com/billing/images/reportIn.png" class="myCategory" />
	<p align="center"> <label>Reports</label></p>
</div>



<!--- inner grids-->