<?php
$countA = 0;
$countB = 0;
$countAB = 0;
$countO = 0;




for ($i = 0; $i < count($mydata); $i++) {


  if ($mydata[$i]->bloodGroup == "A") {
    $countA = $countA + 1;
  }


  if ($mydata[$i]->bloodGroup == "B") {
    $countB = $countB + 1;
  }

  if ($mydata[$i]->bloodGroup == "AB") {
    $countAB = $countAB + 1;
  }


  if ($mydata[$i]->bloodGroup == "O") {
    $countO = $countO + 1;
  }
}
?>



<div class="well" style="margin-left: 51px;">
  <span class="label label-warning">Blood Counts</span>
  <div style="width:50%; margin-top: 20px;">
    <table class="table table-hover table-bordered" id="creditnotetable" style=" margin-left:50px; background-color:white;">
      <thead>
        <tr>
          <th>A</th>
          <th>B</th>
          <th>AB</th>
          <th>O</th>





        </tr>
      </thead>
      <tbody>
        <tr>
          <td><?php echo $countA; ?></td>
          <td><?php echo $countB; ?></td>
          <td><?php echo $countAB; ?></td>
          <td><?php echo $countO; ?></td>

        </tr>
      </tbody>
    </table>
  </div>

</div>