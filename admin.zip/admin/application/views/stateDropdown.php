<select class="form-control topSelect" style="" id="username" name="username" onChange="if (this.value) window.location.href=this.value">
    <option value="#" selected="selected">Select State</option>
    <?php


    for ($i = 0; $i < count($stateNames); $i++) {
        echo "<option value='searchby?keyword=" . $stateNames[$i]->state . "&colName=state'>" . $stateNames[$i]->state . "</option> ";
    }

    ?>
</select>