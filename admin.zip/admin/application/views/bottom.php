</div>


</div>

<!--//Main-->
<!---->
<div class="copy">
  <p> &copy; 2016 Minimal. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">Shubham</a> </p>
</div>
</div>
</div>
<div class="clearfix"> </div>
</div>

<!---->
<!--scrolling js-->
<script src="https://bangalorecalltaxi.com/billing/js/jquery.nicescroll.js"></script>
<script src="https://bangalorecalltaxi.com/billing/js/scripts.js"></script>
<!--//scrolling js-->


</body>

</html>