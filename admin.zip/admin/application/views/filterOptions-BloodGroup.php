<?php

/////////////get Distinct City Names
$this->load->database();

$this->db->select('city');
$this->db->distinct();
$cityquery = $this->db->get('demo');

$cityNames = $cityquery->result();


//print_r($cityNames);
//return $cityNames;

/////////////get City Names

?>


<?php

/////////////get state City Names
$this->load->database();

$this->db->select('state');
$this->db->distinct();
$statequery = $this->db->get('demo');

$stateNames = $statequery->result();


//print_r($stateNames);
//return $cityNames;

/////////////get state Names

?>




<?php

/////////////get state City Names
$this->load->database();

$this->db->select('pinCode');
$this->db->distinct();
$pinCodequery = $this->db->get('demo');

$pinCodeNames = $pinCodequery->result();


//print_r($stateNames);
//return $cityNames;

/////////////get state Names

?>




<?php

/////////////get Distinct PinCode  Names
$this->load->database();

$this->db->select('pinCode');
$this->db->distinct();
$pinCodequery = $this->db->get('demo');

$pinCodeNames = $pinCodequery->result();


//print_r($cityNames);
//return $cityNames;

/////////////get PinCode Names

?>



<?php

/////////////get Distinct Blood Names
$this->load->database();

$this->db->select('bloodGroup');
$this->db->distinct();
$bloodquery = $this->db->get('demo');

$bloodNames = $bloodquery->result();


//print_r($cityNames);
//return $cityNames;

/////////////get Blood Names

?>


<div class="topOP">
    <div class="col-xs-5 topOPinside5" class="">
        <table>
            <tr>
                <td>
                    <form class="form-inline" action="searchby" method="get">
                        <div class="form-group">
                            <label for="exampleInputName2">From</label>
                            <input type="text" class="form-control topDate" name="fromdate" readonly="readonly" id="datepicker" value="" placeholder="--/--/----" style="width:90px;" />
                        </div>
                        <div class="form-group" style="    ">
                            <label for="exampleInputEmail2">To</label>
                            <input type="email" name="enddate" readonly="readonly" id="datepicker2" value="" placeholder="--/--/----" class="form-control topDate" style="width:90px;" />
                        </div>
                        <div class="form-group" style=" margin-right:5px;">
                            <input type="image" src="https://bangalorecalltaxi.com/billing/images/right-arrow.png" alt="Submit" width="20" height="20">
                            <input type="hidden" name="sr" value="">
                        </div>
    </div>
    </td>
    </tr>
    </table>
    </form>
</div>
<div class="col-xs-6" style="float:right;">
    <select class="form-control topSelect" style="" id="username" name="username" onChange="if (this.value) window.location.href=this.value">
        <option value="#" selected="selected">Select Blood Type</option>
        <?php
        for ($i = 0; $i < count($bloodNames); $i++) {
            echo "<option value='searchby?keyword=" . $bloodNames[$i]->bloodGroup . "&colName=bloodGroup'>" . $bloodNames[$i]->bloodGroup . "</option> ";
        }


        ?>
    </select>







    <select class="form-control topSelect" style="" id="username" name="username" onChange="if (this.value) window.location.href=this.value">
        <option value="#" selected="selected">Select Pin Code</option>
        <?php
        for ($i = 0; $i < count($pinCodeNames); $i++) {
            echo "<option value='searchby?keyword=" . $pinCodeNames[$i]->pinCode . "&colName=PinCode'>" . $pinCodeNames[$i]->pinCode . "</option> ";
        }

        ?>
    </select>





    <select class="form-control topSelect" style="" id="username" name="username" onChange="if (this.value) window.location.href=this.value">
        <option value="#" selected="selected">Vaccination Staus</option>
        <option value='searchby?keyword=0&colName=vaccineState'>Fully</option>
        <option value='searchby?keyword=1&colName=vaccineState'>Partial</option>
    </select>







</div>