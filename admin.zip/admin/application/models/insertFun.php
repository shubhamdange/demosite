<?php

class insertFun extends CI_model{

                  function insertData($formArray){
                 // echo "am model";
                  // print_r($formArray);

                  // echo "name is".$formArray['name'];



                     
                  ////insert query

                 $this->load->database();


                 $this->db->insert("demo",$formArray);

                 
                 $insert_id = $this->db->insert_id();

               if($insert_id == 0){ echo "<h4>Contact Number already registered with us</h4>";}else{ echo "<h4>Registered with record</h4>". $insert_id;}


                 
                //  $this->db->query("insert into names(name,number) values('$name', '$number');");

                  ////insert query
                 
               
               
               
               }



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function updateData($keyword, $formArray){
   
echo "am update model";


$this->load->database();

$this->db->where("sr",$keyword);
$this->db->update("names",$formArray);


   }



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



   
function showdata(){
   
   $this->load->database();

      $queryStr = $this->db->get("demo");

      $result = $queryStr->result();

   return $result;
   
      }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



   
function selectedData($keyword,$colName){
   
   $this->load->database();



   $this->db->select('*');
   $this->db->from('demo');
   $this->db-> where($colName, $keyword);
   return $this->db->get()->result();



   
   
      }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



   
function selectedBlood($keyword){
   
   $this->load->database();



   $this->db->select('*');
   $this->db->from('demo');
   $this->db-> where('bloodGroup', $keyword);
   return $this->db->get()->result();



   
   
      }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




}
