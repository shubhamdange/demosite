<?php

class distincts extends CI_model{



//////////////////////////////////////////////////////////////////////////////////////////
    function getDistinctCity(){
$this->load->database();

$this->db->select('city');
$this->db->distinct();
$queryStr = $this->db->get('demo');

$cityNames = $queryStr->result();

return $cityNames;

//print_r($cityNames);

    }

//////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////
function getDistinctBlood(){
    $this->load->database();
    
    $this->db->select('bloodGroup');
    $this->db->distinct();
    $queryStr = $this->db->get('demo');
    
    $bloodGroups = $queryStr->result();
    
    return $bloodGroups;
    
    //print_r($cityNames);
    
        }
    
//////////////////////////////////////////////////////////////////////////////////////////
    

?>


