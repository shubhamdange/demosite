<?php

class mymodel extends CI_model{


	function shout(){

	$this->load->database();
   $queryStr = $this->db->where("number","45748784");
      $queryStr = $this->db->get("names");


   return $result;
   }
}
