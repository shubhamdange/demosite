<?php

class detailsLoad extends CI_model{

         

   
   function loadDetails(){
   
      
      $this->load->database();
      $keyword = $_GET['sr'];
      $this->db->where("sr",$keyword);
     
      $query = $this->db->get("demo");


      $result= $query->result();

     
      return   $result;
      


                       }
      
      
      

}
